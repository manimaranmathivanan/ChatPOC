let config = {
  host    : 'localhost',
  user    : 'root',
  password: 'root',
  database: 'chatpoc'
};
 
module.exports = config;