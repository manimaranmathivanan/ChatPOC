//var http = require("http");
const express = require('express');
let mysql  = require('mysql');
let config = require('./config.js');
const bodyParser = require('body-parser');
const ejs = require('ejs');
var Request = require("request");
const op = require('open');
const opn = require('openurl');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const Nexmo = require('nexmo');
const nexmo = new Nexmo({
  apiKey: "bb1d0c86",
  apiSecret: "LlcYEGbA0KP60Wie"
});
var urlencodedParser = bodyParser.urlencoded({ extended: true });
var rid; 
var phonenum;
var username;
var author1;
var title1;
var description1;
var publishedat1;
var author2;
var title2;
var description2;
var publishedat2;
var nc1 = "";
var nc2 = "";
var nc3 = "";
var nc4 = "";
var nc5 = "";
var nc = "";
var na1="";
var na2="";
var na3="";
var na4="";
var na5="";
app.use(bodyParser.json());
 
app.set('views', __dirname + '/views'); // Render on browser
app.set('view engine', 'html');
app.engine('html', ejs.renderFile);
app.use(express.static(__dirname + '/views'));

io.sockets.on('connection', function(socket) {
  socket.on('username', function(username) {
      socket.username = username;
      io.emit('is_online', '🔵 <i>' + socket.username + ' join the chat..</i>');
  });

  socket.on('disconnect', function(username) {
      io.emit('is_online', '🔴 <i>' + socket.username + ' left the chat..</i>');
  })

  socket.on('chat_message', function(message) {
      io.emit('chat_message', '<strong>' + socket.username + '</strong>: ' + message);
  });

});

app.get('/chatuser', function (req, res) {
  res.render('chatindex.ejs');
});


//const server = app.listen(5000, function () {
const server = http.listen(5000, function () {
  var host = server.address().address
  var port = server.address().port
  console.log("Example app listening at %s:%s Port", host, port)
});

app.get('/', function (req, res) {
  res.render('index');
});


app.post('/reg', urlencodedParser, function (req, res) {
  
  let connection = mysql.createConnection(config);
  let idvalue = '';  
  let sql2 = `SELECT count(*) as rcnt FROM usermaster where phone = '`;  
  sql2 += req.body.number;
  sql2 += `'`;  
  connection.query(sql2, (error, results, fields) => {
    if (error) {
      return console.error(error.message);
    }
    else {    
      idvalue =  results[0].rcnt;      
      if(idvalue == 0) {      
        res.status(401).send('Invalid User');
        return;  
      }
      else {
        
          let phoneNumber = '91' + req.body.number;
          phonenum = req.body.number;          
          //console.log('ph:' + phoneNumber);
           nexmo.verify.request({number: phoneNumber, brand: 'Chat POC'}, (err, 
             result) => {
             if(err) {
               res.sendStatus(500);
             } 
             else
             {
               let requestId = result.request_id;
               console.log('requestid:' + requestId );
               console.log('result:' + result );
               rid = requestId ;
               if(result.status == '0') {
                 res.render('verify', {requestId: requestId}); // Success! Now, have your user enter the PIN
               } 
               else 
               {
                 res.status(401).send(result.error_text);
               }
             }
           });   

          //res.render('dashboard',{ name1: '-', name2: '-', name3: '-', name4: '-', name5: '-', name6: '-', name7: '-', name8: '-', name9: username });              
      }

    } 
  });

  connection.end(); 
    
});


app.post('/verify',urlencodedParser, function (req, res){
  let pin = req.body.pin;
	let requestId = rid;
  console.log(req.body);
	console.log('requestid:' + requestId );
   
  nexmo.verify.check({request_id: requestId, code: pin}, (err, result) => {
    if(err) {
      // handle the error
    } 
    else 
    {
      if(result && result.status == '0') 
      { 
            // Success!
            //res.status(200).send('Account verified!');
            //res.render('status', {message: 'Account verified! ?'});		
            //res.render('dashboard');
            loadUserName();
            ////////////////////////////
                    let i;
                    let j;
                    i = 0;
                    j = i+1;
                    var n =  new Date();
                    var y = n.getFullYear();
                    var m = n.getMonth() + 1;
                    var d = n.getDate();
                    var dt  =   y + "-" + m + "-" + d;
                    //var url = "http://newsapi.org/v2/everything?q=bitcoin&from=2020-01-26&sortBy=publishedAt&apiKey=d43f479b692c435aba64051687275b57";
                    var url = "http://newsapi.org/v2/everything?q=bitcoin&from=";
                    url = url + dt;
                    url = url + "&sortBy=publishedAt&apiKey=d43f479b692c435aba64051687275b57";
                    //console.log('link: ' + url);
          
                    Request.get(url, (error, response, body) => {
                       if(error) {
                     	        return console.dir(error);
                       }
                       else {
          
                         var json = JSON.parse(body);			
          
                         //console.dir('st:' + json.status);
          
                         if(json.status=="error")
                         {
                             console.dir(JSON.parse(body));    
                         }
                         else 
                         {
                           //console.dir(JSON.parse(body));
                          
                           author1 = json.articles[i].author; 
                           title1 = json.articles[i].title; 
                           description1 = json.articles[i].description; 
                           publishedat1 = json.articles[i].publishedAt; 	
                           author2 = json.articles[j].author; 
                           title2 = json.articles[j].title; 
                           description2 = json.articles[j].description; 
                           publishedat2 = json.articles[j].publishedAt; 	      
                           //console.log('Data'+ title1);
            
                           res.render('dashboard',{ name1: author1, name2: title1, name3: description1, name4: publishedat1, name5: author2, name6: title2, name7: description2, name8: publishedat2, name9: username });        
                         }
                      }
                      
                    });
                    ///////////////////////////////////////

                    //res.render('dashboard',{ name1: '-', name2: '-', name3: '-', name4: '-', name5: '-', name6: '-', name7: '-', name8: '-', name9: username });      
      }
      else {
        // handle the error - e.g. wrong PIN
	      res.render('status');
      }
    }
  });
});

function loadUserName(){
      
  let connection = mysql.createConnection(config);
  let idvalue = '';
  // insert statment 
  let sql2 = `SELECT name as nt FROM usermaster where phone = '`;  
  sql2 += phonenum;
  sql2 += `'`;  
  console.log(sql2);
  connection.query(sql2, (error, results, fields) => {
      if (error) {
        return console.error(error.message);
      }
      console.log(results);
      username = results[0].nt;                     
  });

  connection.end();
}

app.post('/searchuser', urlencodedParser, function (req, res) {
  
  if (req.body.fname == "") {    
    res.status(200).send('Invalid User!');
    return;
  }
  let connection = mysql.createConnection(config);
  let idvalue = '';

  let sql3 = `SELECT count(*) as rcnt FROM usermaster where name like '`;  
  sql3 += req.body.fname;
  sql3 += `%'`;  
  connection.query(sql3, (error, results, fields) => {
    if (error) {
      return console.error(error.message);
    }
    else {
      idvalue =  results[0].rcnt;      
      if(idvalue == 0) {      
        res.status(401).send('User not found..');          
      }
      else {

            let sql2 = `SELECT * FROM usermaster where name like '`;  
            sql2 += req.body.fname;
            sql2 += `%'`;  
            console.log(sql2);
            connection.query(sql2, (error, results, fields) => {
                if (error) {
                  return console.error(error.message);
                }
                console.log(results);
                var search_names = results;


                var uname1 = "";
                var uname2 = "";
                var uname3 = "";
                var uname4 = "";
                var uname5 = "";

                var add1 = "";
                var add2 = "";
                var add3 = "";
                var add4 = "";
                var add5 = "";

                //var json = JSON.parse(results);			
                
                if (idvalue == 1) {
                  uname1 = results[0].name; 
                  add1 = results[0].address; 
                }
                else if (idvalue == 2) 
                {
                  uname1 = results[0].name; 
                  uname2 = results[1].name; 
                  add1 = results[0].address; 
                  add2 = results[1].address; 
                }
                else if (idvalue == 3) 
                {
                  uname1 = results[0].name; 
                  uname2 = results[1].name; 
                  uname3 = results[2].name; 
                  add1 = results[0].address; 
                  add2 = results[1].address; 
                  add3 = results[2].address; 
                }
                else if (idvalue == 4) 
                {
                  uname1 = results[0].name; 
                  uname2 = results[1].name; 
                  uname3 = results[2].name; 
                  uname4 = results[3].name; 
                  add1 = results[0].address; 
                  add2 = results[1].address; 
                  add3 = results[2].address; 
                  add4 = results[3].address; 
                }
                else if (idvalue == 5) 
                {
                  uname1 = results[0].name; 
                  uname2 = results[1].name; 
                  uname3 = results[2].name; 
                  uname4 = results[3].name; 
                  uname5 = results[4].name; 
                  add1 = results[0].address; 
                  add2 = results[1].address; 
                  add3 = results[2].address; 
                  add4 = results[3].address; 
                  add5 = results[4].address; 
                }

                res.render('searchuser',{ name1: uname1, name2: uname2, name3: uname3, name4: uname4, name5: uname5, name6: add1, name7: add2, name8: add3, name9: add4, name10: add5 });      

                ////////////
                // var addr;
                // var urladd;
                // addr = results[0].address;
                // urladd = "https://www.google.co.in/maps/search/";
                // urladd = urladd + addr;
                // urladd = urladd + "/@9.9386739,78.0808033,17z/data=!3m1!4b1";      
                // opn.open(urladd);
                ////res.render('searchmap',{ name1: urladd });                    
                //////////////
            });          
            connection.end();
      }
    }
  });
    
});

app.post('/searchmap', urlencodedParser, function (req, res) {
    //console.log('map: ' + req.body.a1);
    var addr = "";
    var urladd = "";
    console.log('Id: ' + req.body.c1);
    console.log('bId: ' + req.body.btnId);
    console.log('name: ' + req.body.n1);
    if(req.body.c1 == 1) {
      addr = req.body.a1;
      na1 = req.body.n1;      
      nc = "1";
     }
     else if(req.body.c1 == 2) 
     {
      addr = req.body.a2;
      na1 = req.body.n2;      
      nc = "2";
     }
     else if(req.body.c1 == 3) 
     {
      addr = req.body.a3;
      na1 = req.body.n3;      
      nc = "3";
     }
     else if(req.body.c1 == 4) 
     {
      addr = req.body.a4;
      na1 = req.body.n4;      
      nc = "4";
     }
     else if(req.body.c1 == 5) 
     {
      addr = req.body.a5;
      na1 = req.body.n5;      
      nc = "5";
     }
     
     if(req.body.btnId == 1) {
          if (addr == "") {
            console.log('No address:' + addr);
          }
          else 
          {
                urladd = "https://www.google.co.in/maps/search/";
                urladd = urladd + addr;
                urladd = urladd + "/@9.9386739,78.0808033,17z/data=!3m1!4b1";      
                opn.open(urladd);
              ////res.render('searchmap',{ name1: urladd });   
          }     
     }
     else if(req.body.btnId == 2) {
       console.log('name1:' + na1);
       if (na1 != ""){          
          res.render('chatindexgroupconfirm', { name1: na1 } );          
       }
        
     }
     
});

app.get('/chatusergroup', function (req, res) {
  res.render('chatindexgroup.ejs', { name1: na1 } );          
});

app.get('/form', function (req, res) {
  var html='';
  html +="<body>";
  html += "<form action='/thank'  method='post' name='form1'>";
  html += "<table>";
  html += "<tr>";
  html += "<td>";
  html += "Name:";
  html += "</td>";
  html += "<td>";
  html += "<input type= 'text' name='name'>";
  html += "</td>";
  html += "</tr>";

  html += "<tr>";
  html += "<td>";
  html += "EMail:";
  html += "</td>";
  html += "<td>";
  html += "<input type= 'text' name='email'>";
  html += "</td>";
  html += "</tr>";

  html += "<tr>";
  html += "<td>";
  html += "Address:";
  html += "</td>";
  html += "<td>";
  html += "<input type= 'text' name='address'>";
  html += "</td>";
  html += "</tr>";

  html += "<tr>";
  html += "<td>";
  html += "Mobile Number:";
  html += "</td>";
  html += "<td>";
  html += "<input type= 'text' name='mobilno'>";
  html += "</td>";
  html += "</tr>";

  html += "<tr>";
  html += "<td>";
  html += "&nbsp;";
  html += "</td>";
  html += "<td>";
  html += "<input type='submit' value='submit'>&nbsp;<INPUT type='reset'  value='reset'>";
  html += "</td>";
  html += "</tr>";

  html += "</form>";
  html += "</body>";
  res.send(html);
});

app.post('/thank', urlencodedParser, function (req, res){

  let connection = mysql.createConnection(config);
  let idvalue = "";
  var reply='';

  let dsql = `delete from usermaster where phone = '` ;  
  dsql += req.body.mobilno;
  dsql += `'`;

  connection.query(dsql);

  // insert statment 
  let sql = `INSERT INTO usermaster(name,email,address,phone)VALUES('` ;
  sql += req.body.name;
  sql += `', '`
  sql += req.body.email;
  sql += `', '`
  sql += req.body.address;
  sql += `', '`
  sql += req.body.mobilno;
  sql += `')`;

  // execute the insert statment
  connection.query(sql);
 
  connection.end();

  reply += "<h1>Registration Successfully done</h1>";
  reply += "</p>";  
  reply += "Name : " + req.body.name;
  reply += "</p>";
  reply += "Email : " + req.body.email; 
  reply += "</p>";
  reply += "Address : " + req.body.address;
  reply += "</p>";
  reply += "Mobile Number : " + req.body.mobilno;

  res.send(reply);
 });